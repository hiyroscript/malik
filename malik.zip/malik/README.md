# MALIK

A runner game by **hiyroscript**. Two modes, six worlds, skins, skills, EN/FR.

---

## 1. Put it on GitHub

1. Make a new **public** repo (name it `malik`).
2. Upload everything in this folder, keeping the structure:

```
index.html
css/style.css
js/data.js   js/core.js   js/gen.js   js/game.js   js/ui.js
assets/music/     ← your songs go here
```

3. Repo → **Settings → Pages** → Source: `Deploy from a branch`, Branch: `main`, Folder: `/ (root)` → Save.
4. Wait ~1 minute. Your link appears at the top of that page:
   `https://YOURNAME.github.io/malik/`

Open it and confirm the game runs before moving on.

## 2. Embed it in Google Sites

In your site: **Insert → Embed → By URL**, paste the GitHub Pages link, click Insert.

Then drag the box to full width and make it as tall as you can. The game letterboxes itself, so a wide, short box wastes space — aim for roughly a 16:9 shape.

> Sound will not start until the player taps or clicks once. That is a browser rule, not a bug. The splash screen and menu give them plenty of chances.

---

## 3. Adding your music

Drop your files into `assets/music/` using **exactly** these names:

| File | World |
|---|---|
| `blank.mp3` | BLANK |
| `wuste.mp3` | WÜSTE |
| `menimienai.mp3` | ME NI MIENAI |
| `malik.mp3` | MALIK |
| `wardsback.mp3` | WARDSBACK |
| `gum.mp3` | CHEWING-GUM |

That is all. No code changes. Missing files just play silence, so you can add them one at a time.

**Format:** `.mp3` is safest everywhere. `.m4a` and `.ogg` also work but `.ogg` fails on older iPhones. Keep each file under ~4 MB or phones on mobile data will hear a gap on the first world switch.

**Looping:** every track loops seamlessly, so trim silence off both ends.

**Speed:** the music playback rate follows the game speed automatically — 1.00× to 2.00×. In Settings, *Music pitch follows speed* is on by default (music gets higher as it speeds up, like Geometry Dash). Turn it off to keep the original pitch while still speeding up.

**Crossfade:** world switches crossfade over 1.2 s. Nothing to configure.

To change a filename, edit the `music:` field for that world in `js/data.js`.

---

## 4. Controls

|  | Keyboard | Touch |
|---|---|---|
| Jump / double jump | `Space` `W` `↑` | ▲ button, or tap the right half |
| Slow fall | hold jump while falling | hold ▲ |
| Crouch | `S` `↓` | ▼ button, or hold the left half |
| Skill | `E` or `Shift` | the round button |
| Lanes (MALIK world only) | `A` `D` `←` `→` | ◀ ▶ buttons |
| Pause | `Esc` or `P` | ❚❚ top right |

Left-handed layout is in Settings.

---

## 5. How the pieces fit

| File | What lives there |
|---|---|
| `js/data.js` | Speeds, worlds, palettes, skins, skills, the 12 levels, all EN/FR text |
| `js/gen.js` | Obstacle patterns and the terrain generator |
| `js/game.js` | Physics, collision, world mechanics, rendering |
| `js/ui.js` | Menus, store, locker, settings, HUD |
| `js/core.js` | Save data, daily store rotation, audio, sound effects |

### Things you will probably want to tweak

Everything below is in `js/data.js`.

- **Speed pacing** — `SPEED_STEPS`. Each stage is `3.0 + i * 0.24` seconds, so 1.00× lasts 3 s and 1.95× lasts about 7.6 s. Raise `0.24` to stretch the run out.
- **Breather after a world switch** — `breakTime`. Currently `0.65 s` at 1.00× growing to `2.0 s` at 2.00×.
- **Skin prices** — `PRICE`.
- **Coin rarity** — `COIN_CHANCE` (7.5%) and `SHARD_CHANCE` (1.1%) in `CFG`.
- **Levels** — the `LEVELS` array. Add a row and it appears in Adventure automatically. Level names are in `LEVEL_NAMES` at the bottom of `js/ui.js`.
- **Jump feel** — `JUMP`, `G`, `SLOW_G` in `CFG`. Careful: the generator sizes every gap from these numbers, so changing them rescales the whole game (which is intended).

### The wall

The black wall behind you sits about 235 px back. It only gains ground when you are stuck in gum. One gum hit is survivable with room to spare; a second within about 1.4 seconds is not. Revive deliberately does not save you from the wall.

---

## 6. Saving

Progress lives in the browser's local storage under `malik.save.v1` — coins, shards, skins, skills, high score, level progress, settings, and the private seed that makes your shop different from everyone else's.

Two things to know: clearing site data wipes it, and progress does not follow a player between their phone and their computer. Settings has a reset button that asks twice.

The shop rolls 5 skins at midnight UTC. The line-up is derived from that private seed plus the date, so no two players see the same shop, and it stays put if they reload.
